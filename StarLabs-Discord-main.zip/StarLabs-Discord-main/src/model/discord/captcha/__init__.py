from .nocaptcha import NoCaptcha
from .capsolver import Capsolver

__all__ = ["NoCaptcha", "Capsolver"]
